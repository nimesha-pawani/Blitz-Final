<?php
/* include 'function.php'; */
include 'sidebar.php';
include 'header.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blitz</title>
    <link rel="stylesheet" href="manage-leave.css">
</head>
<body>
    
    <section>
        
        <div class="page-content">
    
                <div class="container">
    
                    <div>
                        <h1>Manage Employee Leaves</h1>
                    </div>
        
                    <div class="all-tasks">

                    <table class="task-tbl">
        
                        <thead>
        
                            <tr>
                                <th>#</th>
                                <th>User</th>
                                <th>Reason</th>
                                <th>From</th>
                                <th>To </th>
                                <th>Action</th>
                            </tr>
        
                            <?php
        
                                $con = mysqli_connect(SERVER, USERNAME, PASSWORD, DATABASE);
                                /* $user = $_SESSION['user']; */
                                $sql = "SELECT id,reason,start_date,last_date,status,username FROM emp_leave WHERE status = 'pending'";
                                
                                $result = mysqli_query($con, $sql);
        
                                if($result==TRUE):
        
                                    $count_rows = mysqli_num_rows($result);
        
                                    if($count_rows > 0):
                                        $i = 1;
                                        while($row = mysqli_fetch_assoc($result)):
                                            
                                            $id = $row['id'];
                                            $reason = $row['reason'];
                                            $start_date = $row['start_date'];
                                            $last_date = $row['last_date'];
                                            $status = $row['status'];
                                            $username = $row['username'];
        
                            ?>
                            
                        </thead>
                                        
                        <tbody>         
                            <tr> 
                                <td><?php echo $i; $i++; ?></td>
                                <td><?php echo $username ?></td>
                                <td><?php echo $reason ?></td>
                                <td><?php echo $start_date ?></td>
                                <td><?php echo $last_date ?></td>
                                <td class="action-col">
                                    <a href="read-notification?id=<?=$id?>"  onclick="return confirm('Are you sure you want to remove notification?')">Delete<
                                </td>
                            </tr>
                        </tbody>
                                        
                                        <?php endwhile ?>
        
                                    <?php else: ?>
        
                                        <tr>
                                            <td colspan="5">No leaves applied yet</td>
                                        </tr>
        
                                    <?php endif ?>
        
                                <?php endif ?>            
        
                    </table>
    
                </div>
    
        </div>

    </section>

</body>
</html>