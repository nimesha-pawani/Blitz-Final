<?php
include 'sidebar.php';
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedbacks</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>



<div class="content-right">
  <div>
      <div class="nav" >
          <ul style="list-style-type:none; display:inline;">
            <li><a href="about.php" class="top-nav-link">HOME</a></li>
            <li><a href="about.php" class="top-nav-link">ABOUT</a></li>
            <li><a href="help.php" class="top-nav-link">HELP</a></li>
            <li><a href="notification.php" class="top-nav-link">NOTIFICATION</a></li>
        </ul>
      </div>
  </div>


    <div class="topic">   

<h2 style="margin-top:100px;">Departments</h2>

</div>
<div class="btn-box">
<div class="btn add-btn"><a href="createDept.php"> ADD Department </a> </div>
</div>

<!-- <form> -->

<table class="table">
    <thead>
        
        <tr>
            <th> Department Name</th>
            <th> Department Head</th>
            <th> No.of Employees</th>
            <th> Feedback</th>
            <th> Action</th>
        </tr>

    </thead>
<tbody>
</div>

</body>
</html>