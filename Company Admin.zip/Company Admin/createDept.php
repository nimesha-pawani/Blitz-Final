<?php
include 'sidebar.php';
include 'header.php';
if(!isset($mysqli)){include("connection.php");}
$mysqli = connect();
if(isset($_POST['submit'])) {
    $name = $_POST['dename'];
    $depthead = $_POST['depthead'];
    $description = $_POST['description'];
  
    $data = '';
    if(isset($user_ids)){
        $data = implode(',',$user_ids);
    }
    $qry = "INSERT INTO `department`(`dename`, `depthead`,`description`) VALUES ('$dename','$depthead','$description')";
    if(mysqli_query($mysqli,$qry)){
        header('location:table.php');
    }
    else{
        echo mysqli_error($mysqli);
    }
}

?>

<link rel="stylesheet" href="createdept.css">
<title>Blitz</title>
<br/> <br/><br/> <br/> <br/><br/>
<h2>New Department</h2>
<form class="form-inline" action="" method="post" autocomplete="off">
    <label for="name">Department Name:</label>
    <input type="text" id="dename" placeholder="Enter Department Name" name="dename" required>
    
    <label for="depthead">Department Head:</label>
    <input type="text" id="depthead" placeholder="Enter Department Head's Name" name="depthead" required>
        

    <label for="description">Description:</label>
    <textarea required id="description" name="description"></textarea>
    <div class="inline-block">
        <div class="bar">
            <button class="inner1" type="submit" name="submit"><a href="table.php"><b>Save</b></button>
            <button class="inner2" type="input" name="reset"><b>Cancel</b></button>
        </div>
    </div>
</form>
</body>

</html>