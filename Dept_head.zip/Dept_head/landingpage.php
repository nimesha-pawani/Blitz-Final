<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styleforlanding.css">
    <script src="https://kit.fontawesome.com/21e5980a06.js" crossorigin="anonymous"></script>
</head>
    <body>
	<nav>
		<div class="logo">
			<img src="blitzi.png" alt="logo" />
		</div>
		<ul>    
			<li><a href="About.php">About</a></li>    
			<li><a href="help.php">Help</a></li>    
			<li><a href="register.php">Register</a></li>    
			<li><a href="login.php">Login</a></li>    
		</ul>
	</nav>
	<br></br>
    <div class="word">
	We appreciate you for more than just your work. We also want to
	celebrate your character and the positive effect you have on others.
	<br>
    </br>
	Warmly welcome to the rewarding space for your contribution towards us!
	<br>
	<br>
	<br>
	<a href="register.php">Get Started<i class="fa-sharp fa-solid fa-arrow-right"></i></a>
    </div>

</body>