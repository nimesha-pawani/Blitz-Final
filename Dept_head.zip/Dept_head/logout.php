<?php
    include "config.php";
    session_unset();
    session_destroy();
    echo "<script>location.href = 'http://localhost/Blitz/Dept_head/landingpage.php'</script>"
?>
<html