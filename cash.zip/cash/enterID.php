<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
	 <link rel="stylesheet" href="done.css">
    <title>UniqueID</title>
  </head>
  <body>

    <div class="container">
	<form method="post" action="" class="box">
	<h3>To check the availability of the Offer,<br/> Enter the Unique ID of your Customer!</h3>
      <form action="redeem.php">
        <div class="input-box">
          <input type="text" placeholder="Enter Unique ID" required>
          <div class="underline"></div>
        </div>
        <div class="input-box button">
          <input type="submit" href="redeem.php">
        </div>
      </form>
		
<img src="logo.png" alt="" >
    </div>
  </body>
</html>

